#find_files
==========

##findFileByName:
---------------

	Find the files in a directory by using filename 

Example
-------

##findFileByName::
----------------

	##findFileByName('main.xml', '/path/to/dir')


findAllFileByName:
------------------

	Find the all files in a directory by using filename 

Example
-------

findAllFileByName::
-------------------

	findAllFileByName('main.xml', '/path/to/dir')


##findFileByPattern:
------------------

	Find the all files in a directory by using extension(ex: xml,html,doc...etc) 

Example
-------

##findFileByPattern::
-------------------

	##findFileByPattern('*.xml', '/path/to/dir')
